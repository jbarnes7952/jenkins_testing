from django.urls import path, include
from rest_framework import routers

from . import api
from . import views

router = routers.DefaultRouter()
router.register(r'todo', api.ToDoViewSet)


urlpatterns = (
    # urls for Django Rest Framework API
    path('api/v1/', include(router.urls)),
)

urlpatterns += (
    # urls for ToDo
    path('Todos/todo/', views.ToDoListView.as_view(), name='Todos_todo_list'),
    path('Todos/todo/create/', views.ToDoCreateView.as_view(), name='Todos_todo_create'),
    path('Todos/todo/detail/<slug:slug>/', views.ToDoDetailView.as_view(), name='Todos_todo_detail'),
    path('Todos/todo/update/<slug:slug>/', views.ToDoUpdateView.as_view(), name='Todos_todo_update'),
)

