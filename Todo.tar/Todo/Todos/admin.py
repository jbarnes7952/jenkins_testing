from django.contrib import admin
from django import forms
from .models import ToDo

class ToDoAdminForm(forms.ModelForm):

    class Meta:
        model = ToDo
        fields = '__all__'


class ToDoAdmin(admin.ModelAdmin):
    form = ToDoAdminForm
    list_display = ['name', 'slug', 'created', 'last_updated', 'Task']
    readonly_fields = ['name', 'slug', 'created', 'last_updated', 'Task']

admin.site.register(ToDo, ToDoAdmin)


