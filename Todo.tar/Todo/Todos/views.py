from django.views.generic import DetailView, ListView, UpdateView, CreateView
from .models import ToDo
from .forms import ToDoForm


class ToDoListView(ListView):
    model = ToDo


class ToDoCreateView(CreateView):
    model = ToDo
    form_class = ToDoForm


class ToDoDetailView(DetailView):
    model = ToDo


class ToDoUpdateView(UpdateView):
    model = ToDo
    form_class = ToDoForm

