from . import models
from . import serializers
from rest_framework import viewsets, permissions


class ToDoViewSet(viewsets.ModelViewSet):
    """ViewSet for the ToDo class"""

    queryset = models.ToDo.objects.all()
    serializer_class = serializers.ToDoSerializer
    permission_classes = [permissions.IsAuthenticated]


